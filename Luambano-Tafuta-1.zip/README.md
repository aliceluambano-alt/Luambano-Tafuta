# 🔍 ALuambanoTafuta

**App rahisi na yenye nguvu ya kutafuta muziki, picha, video, faili na programu kwenye computer yako.**

Inatumia **SQLite** kwa index ya haraka (Offline-first) + toleo la Browser.

![Logo](logo.png)

---

## Features

- 🔍 Tafuta kwa jina la faili (haraka sana baada ya index)
- 🎵 Filters: Muziki, Picha, Video, Hati, Programu
- 💾 SQLite index – scan mara moja, tafuta mara nyingi
- 🌐 Offline + Online ready
- 🖥️ Toleo la Desktop (Python) + Toleo la Browser (HTML)
- 🪟 Windows, macOS, Linux

---

## Installation (Rahisi)

### Windows
1. Download / Clone repo hii
2. Double-click `Anzisha_Windows.bat`

### macOS / Linux
```bash
chmod +x Anzisha_Linux_Mac.sh
./Anzisha_Linux_Mac.sh
```

**Mahitaji:** Python 3.7+ (tkinter + sqlite3 zinakuja na Python)

---

## Jinsi ya kutumia

1. Chagua folda
2. Bonyeza **Jenga Index**
3. Andika neno → **Tafuta**
4. Double-click faili ili kuifungua

---

## Structure

```
ALuambanoTafuta/
├── ALuambanoTafuta.py      # App kuu
├── Anzisha_Windows.bat
├── Anzisha_Linux_Mac.sh
├── logo.png / icon.png
├── browser/
│   └── index.html          # Browser version
├── README.md
└── SOMA_MIMI.txt           # Maelekezo kwa Kiswahili
```

---

## License

MIT License – unaweza kutumia, kurekebisha na kugawa kwa uhuru.

---

## Author

Imetengenezwa kwa ajili ya watumiaji wa Kiswahili.

**ALuambanoTafuta** – Tafuta kwa urahisi.
