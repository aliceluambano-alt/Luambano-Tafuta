@echo off
title ALuambanoTafuta
cd /d "%~dp0"

echo.
echo  ========================================
echo       ALuambanoTafuta  v1.0
echo  ========================================
echo.

where python >nul 2>&1
if %errorlevel%==0 (
    python ALuambanoTafuta.py
) else (
    where py >nul 2>&1
    if %errorlevel%==0 (
        py ALuambanoTafuta.py
    ) else (
        echo [KOSA] Python haijapatikana!
        echo Pakua Python kutoka: https://www.python.org/downloads/
        echo Hakikisha umeweka alama kwenye "Add Python to PATH"
        pause
    )
)
