#!/usr/bin/env python3
"""
ALuambanoTafuta
App moja ya kutafuta muziki, picha, video, faili na programu.
- Offline: inatumia SQLite index (haraka)
- Online: inaweza kufungua toleo la browser pia
"""

import os
import sys
import sqlite3
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
import platform
from pathlib import Path
from datetime import datetime
import threading
import webbrowser
import socket

# ================== CONFIG ==================
APP_NAME = "ALuambanoTafuta"
DB_NAME = "aluambano_index.db"
MAX_RESULTS = 5000
VERSION = "1.0"

FILE_TYPES = {
    "Muziki": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".opus", ".aiff"},
    "Picha": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".svg", ".heic", ".raw"},
    "Video": {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".3gp", ".mpeg"},
    "Hati": {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".odt"},
    "Programu": {".exe", ".msi", ".app", ".dmg", ".deb", ".rpm", ".apk", ".bat", ".sh", ".cmd"},
}

SKIP_DIRS = {
    "$Recycle.Bin", "System Volume Information", "node_modules",
    "__pycache__", ".git", ".svn", "AppData", "Library", "Cache",
    "Temporary Internet Files", "Windows", "ProgramData"
}


def has_internet(timeout=2):
    """Angalia kama kuna mtandao"""
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=timeout)
        return True
    except OSError:
        return False


class Database:
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                path TEXT NOT NULL UNIQUE,
                ext TEXT,
                ftype TEXT,
                size INTEGER,
                mtime REAL,
                indexed_at TEXT
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_name ON files(name COLLATE NOCASE)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ftype ON files(ftype)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ext ON files(ext)")
        self.conn.commit()

    def clear_all(self):
        self.conn.execute("DELETE FROM files")
        self.conn.commit()

    def insert_many(self, rows):
        self.conn.executemany("""
            INSERT OR REPLACE INTO files (name, path, ext, ftype, size, mtime, indexed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, rows)
        self.conn.commit()

    def search(self, term, allowed_types=None, limit=MAX_RESULTS):
        sql = "SELECT name, ftype, size, mtime, path FROM files WHERE 1=1"
        params = []
        if term:
            sql += " AND name LIKE ? COLLATE NOCASE"
            params.append(f"%{term}%")
        if allowed_types:
            placeholders = ",".join("?" * len(allowed_types))
            sql += f" AND ftype IN ({placeholders})"
            params.extend(allowed_types)
        sql += " ORDER BY name LIMIT ?"
        params.append(limit)
        return self.conn.execute(sql, params).fetchall()

    def count(self):
        return self.conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]

    def close(self):
        self.conn.close()


class ALuambanoTafutaApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} v{VERSION}")
        self.root.geometry("980x700")
        self.root.minsize(780, 550)

        # Paths
        if getattr(sys, 'frozen', False):
            self.base_dir = Path(sys.executable).parent
        else:
            self.base_dir = Path(__file__).parent

        self.db_path = self.base_dir / DB_NAME
        self.html_path = self.base_dir / "browser" / "index.html"
        self.db = Database(str(self.db_path))

        # Style
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TButton", padding=6)
        style.configure("Treeview", rowheight=26)
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"))

        self.search_path = tk.StringVar(value=str(Path.home()))
        self.search_term = tk.StringVar()
        self.selected_types = {k: tk.BooleanVar(value=True) for k in FILE_TYPES}
        self.selected_types["Yote"] = tk.BooleanVar(value=False)
        self.is_busy = False
        self.online = has_internet()

        # Load logo
        self.logo_img = None
        logo_path = self.base_dir / "logo.png"
        if logo_path.exists():
            try:
                from PIL import Image, ImageTk
                img = Image.open(logo_path).resize((48, 48), Image.Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(img)
            except Exception:
                self.logo_img = None

        # Try set window icon
        icon_path = self.base_dir / "icon.png"
        if icon_path.exists():
            try:
                self.root.iconphoto(True, tk.PhotoImage(file=str(icon_path)))
            except Exception:
                pass

        self._build_ui()
        self._update_status_count()
        self._show_network_status()

    def _build_ui(self):
        # Header with logo
        header = ttk.Frame(self.root, padding=(12, 10))
        header.pack(fill=tk.X)

        if self.logo_img:
            ttk.Label(header, image=self.logo_img).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(header, text=APP_NAME, style="Header.TLabel").pack(side=tk.LEFT)
        self.net_label = ttk.Label(header, text="")
        self.net_label.pack(side=tk.RIGHT)

        # Top controls
        top = ttk.Frame(self.root, padding=10)
        top.pack(fill=tk.X)

        ttk.Label(top, text="Folda:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        ttk.Entry(top, textvariable=self.search_path, width=55).grid(row=0, column=1, sticky=tk.EW, padx=5)
        ttk.Button(top, text="Chagua Folda...", command=self.choose_folder).grid(row=0, column=2, padx=3)
        ttk.Button(top, text="Jenga Index", command=self.start_index).grid(row=0, column=3, padx=3)

        ttk.Label(top, text="Tafuta:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5), pady=(8, 0))
        search_entry = ttk.Entry(top, textvariable=self.search_term, width=55)
        search_entry.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=(8, 0))
        search_entry.bind("<Return>", lambda e: self.start_search())
        ttk.Button(top, text="Tafuta", command=self.start_search).grid(row=1, column=2, padx=3, pady=(8, 0))
        ttk.Button(top, text="Futa Index", command=self.clear_index).grid(row=1, column=3, padx=3, pady=(8, 0))

        top.columnconfigure(1, weight=1)

        # Filters
        filters = ttk.LabelFrame(self.root, text="Aina ya Faili", padding=8)
        filters.pack(fill=tk.X, padx=10, pady=4)
        for i, (name, var) in enumerate(self.selected_types.items()):
            ttk.Checkbutton(filters, text=name, variable=var, command=self._on_type_change).grid(row=0, column=i, padx=7)

        # Results
        mid = ttk.Frame(self.root, padding=(10, 5))
        mid.pack(fill=tk.BOTH, expand=True)

        columns = ("jina", "aina", "ukubwa", "tarehe", "path")
        self.tree = ttk.Treeview(mid, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("jina", text="Jina la Faili")
        self.tree.heading("aina", text="Aina")
        self.tree.heading("ukubwa", text="Ukubwa")
        self.tree.heading("tarehe", text="Ilibadilishwa")
        self.tree.heading("path", text="Mahali")

        self.tree.column("jina", width=230, minwidth=120)
        self.tree.column("aina", width=90, minwidth=60)
        self.tree.column("ukubwa", width=90, minwidth=70)
        self.tree.column("tarehe", width=135, minwidth=100)
        self.tree.column("path", width=320, minwidth=150)

        vsb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(mid, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        mid.rowconfigure(0, weight=1)
        mid.columnconfigure(0, weight=1)

        self.tree.bind("<Double-1>", self.open_file)
        self.tree.bind("<Return>", self.open_file)

        # Status
        self.status = ttk.Label(self.root, text="", relief=tk.SUNKEN, anchor=tk.W, padding=5)
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

        # Bottom buttons
        bottom = ttk.Frame(self.root, padding=8)
        bottom.pack(fill=tk.X)
        ttk.Button(bottom, text="Fungua Faili", command=self.open_file).pack(side=tk.LEFT, padx=4)
        ttk.Button(bottom, text="Fungua Folda", command=self.open_folder).pack(side=tk.LEFT, padx=4)
        ttk.Button(bottom, text="Nakili Path", command=self.copy_path).pack(side=tk.LEFT, padx=4)
        ttk.Button(bottom, text="Fungua Toleo la Browser", command=self.open_browser_version).pack(side=tk.LEFT, padx=8)
        ttk.Button(bottom, text="Futa Matokeo", command=self.clear_results).pack(side=tk.RIGHT, padx=4)

    def _show_network_status(self):
        if self.online:
            self.net_label.config(text="🟢 Mtandao upo", foreground="green")
        else:
            self.net_label.config(text="🔴 Hakuna mtandao (Offline mode)", foreground="red")

    def _on_type_change(self):
        if self.selected_types["Yote"].get():
            for k, v in self.selected_types.items():
                if k != "Yote":
                    v.set(False)

    def _update_status_count(self):
        try:
            count = self.db.count()
            mode = "Online" if self.online else "Offline"
            self.status.config(text=f"[{mode}] Database: {count:,} faili  |  {self.db_path.name}")
        except Exception:
            self.status.config(text="Database haijaanzishwa.")

    def choose_folder(self):
        folder = filedialog.askdirectory(initialdir=self.search_path.get())
        if folder:
            self.search_path.set(folder)

    def clear_index(self):
        if messagebox.askyesno("Thibitisha", "Futa index yote?"):
            self.db.clear_all()
            self.clear_results()
            self._update_status_count()
            messagebox.showinfo("Imefanyika", "Index imefutwa.")

    def start_index(self):
        if self.is_busy:
            messagebox.showinfo("Subiri", "Kazi inaendelea...")
            return
        path = self.search_path.get().strip()
        if not path or not os.path.isdir(path):
            messagebox.showerror("Kosa", "Chagua folda sahihi.")
            return
        if not messagebox.askyesno("Jenga Index", f"Scan folda:\n{path}\n\nEndelea?"):
            return

        self.is_busy = True
        self.status.config(text="Inascan na kujenga index... subiri.")
        threading.Thread(target=self._do_index, args=(path,), daemon=True).start()

    def _do_index(self, root_path):
        rows = []
        now = datetime.now().isoformat(timespec="seconds")
        count = 0
        try:
            for dirpath, dirnames, filenames in os.walk(root_path):
                dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
                for fname in filenames:
                    full = os.path.join(dirpath, fname)
                    try:
                        stat = os.stat(full)
                        ext = Path(fname).suffix.lower()
                        ftype = self._guess_type(ext)
                        rows.append((fname, full, ext, ftype, stat.st_size, stat.st_mtime, now))
                        count += 1
                        if len(rows) >= 2000:
                            self.db.insert_many(rows)
                            rows = []
                            self.root.after(0, lambda c=count: self.status.config(text=f"Inascan... {c:,} faili"))
                    except (OSError, PermissionError):
                        continue
            if rows:
                self.db.insert_many(rows)
            self.root.after(0, lambda: self._index_done(count))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Kosa", str(e)))
            self.root.after(0, self._index_done_error)

    def _index_done(self, count):
        self.is_busy = False
        self._update_status_count()
        messagebox.showinfo("Imefanyika", f"Index imejengwa!\n{count:,} faili zimehifadhiwa.")

    def _index_done_error(self):
        self.is_busy = False
        self._update_status_count()

    def start_search(self):
        if self.is_busy:
            return
        term = self.search_term.get().strip()
        allowed = None
        if not self.selected_types["Yote"].get():
            allowed = [k for k, v in self.selected_types.items() if k != "Yote" and v.get()]
            if not allowed:
                messagebox.showwarning("Onyo", "Chagua angalau aina moja.")
                return
        self.clear_results()
        self.status.config(text="Inatafuta...")
        threading.Thread(target=self._do_search, args=(term, allowed), daemon=True).start()

    def _do_search(self, term, allowed):
        try:
            rows = self.db.search(term, allowed, MAX_RESULTS)
            self.root.after(0, lambda: self._show_results(rows))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Kosa", str(e)))

    def _show_results(self, rows):
        for row in rows:
            size = self._format_size(row["size"])
            mtime = datetime.fromtimestamp(row["mtime"]).strftime("%Y-%m-%d %H:%M")
            self.tree.insert("", tk.END, values=(row["name"], row["ftype"], size, mtime, row["path"]))
        count = len(rows)
        msg = f"Imepatikana: {count:,} faili"
        if count >= MAX_RESULTS:
            msg += f" (max {MAX_RESULTS:,})"
        self.status.config(text=f"{msg}  |  Jumla kwenye DB: {self.db.count():,}")

    def _guess_type(self, ext):
        for name, exts in FILE_TYPES.items():
            if ext in exts:
                return name
        return "Nyingine"

    def _format_size(self, size):
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"

    def _get_selected_path(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.item(sel[0])["values"][4]

    def open_file(self, event=None):
        path = self._get_selected_path()
        if not path:
            messagebox.showinfo("Habari", "Chagua faili kwanza.")
            return
        try:
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.run(["open", path], check=False)
            else:
                subprocess.run(["xdg-open", path], check=False)
        except Exception as e:
            messagebox.showerror("Kosa", str(e))

    def open_folder(self):
        path = self._get_selected_path()
        if not path:
            return
        folder = os.path.dirname(path)
        try:
            if platform.system() == "Windows":
                os.startfile(folder)
            elif platform.system() == "Darwin":
                subprocess.run(["open", folder], check=False)
            else:
                subprocess.run(["xdg-open", folder], check=False)
        except Exception as e:
            messagebox.showerror("Kosa", str(e))

    def copy_path(self):
        path = self._get_selected_path()
        if not path:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(path)
        self.status.config(text=f"Path imenakiliwa: {path}")

    def clear_results(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

    def open_browser_version(self):
        """Fungua toleo la HTML (inatumika vizuri zaidi kama kuna mtandao au browser ya kisasa)"""
        if self.html_path.exists():
            webbrowser.open(self.html_path.as_uri())
        else:
            messagebox.showwarning("Haipo", "Toleo la browser halipatikani.\nHakikisha folda 'browser' ipo.")

    def on_closing(self):
        self.db.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    app = ALuambanoTafutaApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()
