#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  ========================================"
echo "       ALuambanoTafuta  v1.0"
echo "  ========================================"
echo ""

if command -v python3 &>/dev/null; then
    python3 ALuambanoTafuta.py
elif command -v python &>/dev/null; then
    python ALuambanoTafuta.py
else
    echo "[KOSA] Python haijapatikana!"
    echo "Sakinisha Python 3 kwanza."
    exit 1
fi
